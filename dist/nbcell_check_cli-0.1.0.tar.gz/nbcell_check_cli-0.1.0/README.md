nbcell-check-cli searches cells in a notebook that match a regex
